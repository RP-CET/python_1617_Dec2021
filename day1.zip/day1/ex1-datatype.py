# i is a floating point number
i = 3.0
#print(type(i))

j = 3
#print(type(j))

k = i + j
#print(k)

s1 = "hello"
s2 = "world"
print(s1 + " " + s2)
print(s1 + str(3))

n = "23"
print(int(n) + 2)
print(n + str(2))

